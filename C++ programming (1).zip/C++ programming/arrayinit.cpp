
	#include<iostream.h>
	
	void main()
	{
		int cost[] = { 800 , 1200 , 350 , 2400 , 340};
		int pcode , qty;
		long int total;
		cout << "Enter product code " << endl;
		cin >> pcode;

		if( pcode < 0 || pcode > 4 )
			cout << "Please input valid product code\n";
		else
		{
		  cout << "Enter quantity required \n";
		  cin >> qty;
		  total = cost [ pcode ] * qty;
		  cout << "-------------------------" << endl;
		  cout << "Product code :  " << pcode << endl;
		  cout << "Unit cost    :  " << cost[pcode] << endl;
		  cout << "Quantity     :  " << qty << endl;
		  cout << "Total amount :  " << total << endl;
		  cout << "--------------------------" << endl;
		}
	}