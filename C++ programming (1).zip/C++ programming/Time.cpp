
	#include<iostream.h>

	void main()
	{
	  int h , m , s;
	  cout << "Enter time" << endl;
	  cin >> h >> m >> s;
	  s++;
	  if( s==60)
	  {
		  s = 0;
		  m++;
		  if( m == 60 )
		  {
				m = 0;
				h++;
				if( h == 24 )
					h = 0;
		  }
	  }

	  cout << h << ":" << m << ":" << s << endl;
	}