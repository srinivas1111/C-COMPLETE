	#include<iostream.h>
	#include<string.h>

	void main()
	{
		char s[80];		
		int c=0;
		cout << "Enter sentence \n";
		cin . getline( s , 80 , '.' );
		strlwr( s );

		for( int i=0; s[i]!='\0'; i++)
		{
			switch( s[i] )
			{
			case 'a': 
			case 'e':
			case 'i':
			case 'o':
			case 'u': c++;
			}
		}

		cout << "Count of vowels = " << c << endl;
	}

		
