	#include<iostream.h>
	void main()
	{
		char s[80];		
		int c=0;
		cout << "Enter sentence \n";
		cin . getline( s , 80 , '.' );
		 
		for( int i=0; s[i]!='\0'; i++)
		{
			if( s[i] == 32 && s[i+1] != 32 ) c++;
		}

		cout << "Count of words = " << c + 1 << endl;
	}
