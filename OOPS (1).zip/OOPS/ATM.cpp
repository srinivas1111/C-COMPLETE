
	#include<iostream.h>
	#include<conio.h>

	class Atmserver
	{
	private:
			 int amount;
	public:
			 Atmserver()
			 {
				amount = 12250;  // assume minimum balance
				cout << "Welcome " << endl;
				cout << __TIME__ << endl;
				cout << __DATE__ << endl;
			 }

			 void Deposit( int amt )
			 {
				amount = amount + amt;
			 }

			 void Withdraw( int amt )
			 {
				if( (amount - amt) < 250 )
				{
				   cout << "Not enough balance" << endl;
				}
				else
				{
					if( amt > 5000 )
						cout << "Sorry max amount withdraw limit is 5000 Rs" << endl;
					else
					amount = amount - amt;
				}
			 }

			 void Balance()
			 {
				cout << "Balance = " << amount << endl;
			 }

			 ~Atmserver()
			 {
			  cout << "All your transaction saved and updated to server successfully" << endl;
			 }
		};

		void main( )
		{

			clrscr();

			Atmserver c1  , c2;

			c1.Deposit( 2000 );
			c2.Deposit( 3000 );

			c1.Withdraw( 8000 );
			c1.Balance();
			c2.Balance();
		}




