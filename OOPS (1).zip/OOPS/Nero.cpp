
	#include<iostream.h>
	#include<conio.h>
	#include<dos.h>

	class Nero
	{
	public:
		Nero()
		{
		cout << "Init. device" << endl;
		   sleep(2);
		cout << "Identify media type" << endl;
		   sleep(2);
		cout << "Create a temp. folder" << endl;
		   sleep(2);
		}


		~Nero()
		{
		cout << "\nClosing session" << endl;
		sleep(2);
		cout << "Making the cd to reuse" << endl;
		sleep( 2 );
		cout << "Delete folder " << endl;
		sleep(2);
		cout << "Eject cd" << endl;
		}

		void writing( )
		{
		cout << "Allowing the user to choose files" << endl;
		sleep(5);
		for(int i=1; i<=40; i++)
		{
		  cout << (char)219;
		  delay( 200 );  // 1000 ms = 1sec
		}
		}

	};
	void main( )
	{
	  clrscr();

	  Nero n;

	  n.writing();

	}
	
