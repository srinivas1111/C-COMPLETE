	#include<iostream.h>

	class MobileServer
	{
	 private:
			 int amount;
	 public:
			MobileServer()
			{
				cout << "Sim-card activated with free offer of Rs. 10 " << endl;
				amount = 10;
			}

			MobileServer( int v)
			{
				cout << "Sim-card activated with free offer of Rs. " << v  << endl;
				amount = v;
			}

			void call()
			{
				if( amount == 0 )
					cout << "Not enough balance\n";
				else
					amount = amount - 1;
			}

			void GetBalance()
			{
			 cout << "Balance = " << amount << endl;
			}
	};

	void main()
	{
	  MobileServer s1 , s2( 50 );
 
	  for( int i=1; i<=5; i++)
		  s1.call();

	  s1.GetBalance();
	  s2.GetBalance();
	}