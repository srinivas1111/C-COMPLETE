	#include<iostream.h>

	class MobileServer
	{
	 private:
			 int amount;
	 public:
			void activate( )
			{
				amount = 10;
			}

			void call()
			{
				if( amount == 0 )
					cout << "Not enough balance\n";
				else
					amount = amount - 1;
			}

			void GetBalance()
			{
			 cout << "Balance = " << amount << endl;
			}
	};

	void main()
	{
	  MobileServer s1 , s2;
	  s1.activate();
	  s2.activate();

	  for( int i=1; i<=5; i++)
		  s1.call();

	  s1.GetBalance();
	  s2.GetBalance();
	}