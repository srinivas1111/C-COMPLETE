

	#include<iostream.h>
	#include<conio.h>
	#include<dos.h>

	class ChatServer
	{
	public:
		ChatServer()
		{
		cout << "Hi , how are you ?" << endl;
		}

		void chat()
		{
		 while( !kbhit() )
		 {
		 cout << "Message b/w users...." << endl;
		 sleep(1);
		 }
		}

		~ChatServer( )
		{
		cout << "Bye , tc" << endl;
		}
	};

	void main()
	{
	clrscr();

	ChatServer s;
	s.chat();


	}













