	#include<iostream.h>
	class Time
	{
	public:
			int hour , min , sec;
			void PrintMessage()
			{
				if( hour < 12 )
					cout << "Good morning" << endl;
				else if( hour < 16 )
					cout << "Good afternoon" << endl;
				else
					cout << "Good evening" << endl;
			}
	};

	void main()
	{
		 Time t;
		 cout << sizeof( t ) << endl;
		 t.hour = 10;
		 t.min = 20;
		 t.sec = 23;

		 t.PrintMessage();
	}