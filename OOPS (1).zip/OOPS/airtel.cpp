	#include<iostream.h>

	class Airtel
	{
	private:
			int curr;
	public:
			void activate( )
			{
				curr = 10;
			}

			void recharge( int val )
			{
				curr = curr + val;
			}

			int getBalance()
			{
				return curr;
			}
	};

	void main()
	{
		int amt;
		Airtel s1 , s2;
		s1.activate();
		s2.activate();

		cout << "Enter amount to recharge " << endl;
		cin >> amt;
		s1.recharge( amt );

		cout << "Balance = " << s1.getBalance() << endl;
		cout << "Balance = " << s2.getBalance() << endl;
	}