
	#include<iostream.h>
	#include<string.h>

	class iNet
	{
	private:
				int hrs , used;
				char name[20];
				char regFlag;
				static thrs , tused, cnt , talloc;
				
	public:
				iNet(char n[] , int hrsRequired = 10)
				{
				  if( talloc + hrsRequired > thrs )
				  {
				   cout << "Sorry " << n << " , can't allocate due to insufficient hours" << endl;
				   regFlag = 'F';
				  }
				  else
				  {
				   regFlag = 'P';
				   talloc = talloc + hrsRequired;
				   strcpy( name , n );
				   hrs = hrsRequired;
				   used = 0;
				   cnt++;    
				  }
				}

				void Browse(int h )
				{
				  if( regFlag == 'P' )
				  {
				  int remaining = hrs - used;
				  if( remaining - h < 0 )
					  cout << "Please recharge usage" << endl;
				  else
				  {
					  used = used + h;
					  tused = tused + h;
				  }
				  }
				  else
				  cout << "Hey !! , u r not registered or allocated any hours" << endl;
				}

				void MyAccount()
				{
					if( regFlag == 'P' )
					{
					cout << "*******" << name << " account details********\n";
					cout << "Total rented   :" << hrs << endl;
					cout << "Total used     :" << used << endl;
					cout << "Remaining      :" << hrs-used << endl;
					cout << "******************************************\n";
					}
					else
					cout << "Hey !! , u r not registered or allocated any hours" << endl;
				}

				static void Report()
				{
				cout << "************Report***********" << endl;
				cout << "Count of customers    :" << cnt << endl;
				cout << "Total hours rented    :" << thrs << endl;
				cout << "Total usage           :" << tused << endl;
				cout << "Remaining             :" << thrs - tused << endl;
				cout << "*******************************" << endl;
				}
	};

	int iNet::thrs = 50;
	int iNet::tused = 0;
	int iNet::cnt = 0;
	int iNet::talloc=0;

	void main()
	{
		iNet c1("naveen") , c2("syed" , 25 ) , c3("harry", 25 );

		c1.Browse(2);
		c2.Browse(5);
		c3.Browse( 10 );

		c1.MyAccount();
		c2.MyAccount();
		c3.MyAccount();

		iNet::Report();
	}