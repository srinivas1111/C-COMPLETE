	#include<iostream.h>

	class College
	{
	private:
			 int sid , semis , age;
			 char name[20] , gender;
			 static int mc , fc;
	public:
			 void NewAdmission()
			 {
			   cout << "Student id , name , semis , age and gender \n";
			   cin >> sid >> name >> semis >> age >> gender;
			   if( gender == 'm' || gender == 'M')
				   mc++;
			   else
				   fc++;
			 }

			 void MyDetails()
			 {
				cout << sid << "\t" << name << "\t" << semis <<"\t" << age << "\t"  << gender << endl;
			 }

			 static void Report()
			 {
				cout <<"--------< Summary >----------" << endl;
				cout << "Male count   = " << mc << endl;
				cout << "Female count = " << fc << endl;
				cout << "Total count  = " << mc + fc << endl;
				cout << "-----------------------------" << endl;
			 }
	};

	int College::mc = 0;
	int College::fc = 0;

	void main()
	{
		College s1 , s2;
		s1.NewAdmission();
		s2.NewAdmission();

		s1.MyDetails();
		s2.MyDetails();

		College::Report();
	}





