
	#include<iostream.h>
	#include<string.h>

	class iNet
	{
	private:
				int hrs , used;
				char name[20];
				static thrs , tused, cnt;
				
	public:
				iNet(char n[] , int hrsRequired = 10)
				{
				  strcpy( name , n );
				  hrs = hrsRequired;
				  used = 0;
				  cnt++;    
				}

				void Browse(int h )
				{
				  int remaining = hrs - used;
				  if( remaining - h < 0 )
					  cout << "Please recharge usage" << endl;
				  else
				  {
					  used = used + h;
					  tused = tused + h;
				  }
				}

				void MyAccount()
				{
					cout << "*******" << name << " account details********\n";
					cout << "Total rented   :" << hrs << endl;
					cout << "Total used     :" << used << endl;
					cout << "Remaining      :" << hrs-used << endl;
					cout << "******************************************\n";
				}

				static void Report()
				{
				cout << "************Report***********" << endl;
				cout << "Count of customers    :" << cnt << endl;
				cout << "Total hours rented    :" << thrs << endl;
				cout << "Total usage           :" << tused << endl;
				cout << "Remaining             :" << thrs - tused << endl;
				cout << "*******************************" << endl;
				}
	};

	int iNet::thrs = 500;
	int iNet::tused = 0;
	int iNet::cnt = 0;

	void main()
	{
		iNet c1("naveen") , c2("syed" , 25 );

		c1.Browse(2);
		c2.Browse(5);

		c1.MyAccount();
		c2.MyAccount();

		iNet::Report();
	}