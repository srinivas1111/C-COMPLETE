	
	#include<iostream.h>

	class FuelBank
	{	
	private:
			char vno[15];
			float ltrs;
			char type;
			static float dstock , pstock;
			static int cnt;
	public:
			void Fill( )
			{
			  cnt++;
			  cout << "Enter vehicle no , ltrs and type ( D/P ) ?\n";
			  cin >> vno >> ltrs >> type;
			  if( type == 'D' || type == 'd')
				    dstock = dstock - ltrs;
			  if( type == 'P' || type == 'p')
				    pstock = pstock - ltrs;
			}

			static void Stock()
			{
				cout << "-------------------------\n";
				cout << "Diesel stock "<< dstock<<endl;
				cout << "Petrol stock "<< pstock << endl;
				cout << "Count of vehicle " << cnt << endl;
				cout << "--------------------------\n";
			}
		
			void Display()
			{
			cout << "---------------------------\n";
			cout << "Vehicle no. :" << vno << endl
			     << "Ltrs        :" << ltrs << endl
                 << "Type        :" << type<<endl;
			cout << "---------------------------\n";
			}
	};

	float FuelBank::dstock = 5000;
	float FuelBank::pstock = 5000;
	int FuelBank::cnt = 0;

	void main()
	{
		FuelBank v1 , v2 , v3;
		v1.Fill();
		v2.Fill();
		v3.Fill();


		v1.Display();
		v2.Display();
		v3.Display();

		FuelBank::Stock();
	}