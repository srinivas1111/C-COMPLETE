
	#include<iostream.h>
	void swap( int & , int & );
	void main( )
	{
		int a,b;
		cin >> a >> b;
		cout << "Before swapping \n " << a << "\n" << b << endl;
		swap( a , b );
		cout << "After swapping \n " << a << "\n" << b << endl;
	}

	void swap( int &x , int & y )
	{
			int temp;
			temp = x;
			x = y;
			y = temp;
	}