
	#include<iostream.h>

	template<class P,class Q>
	void add( P arg1, Q arg2 )
	{
		cout << "Sum = " << arg1 + arg2 << endl;
	}

	void main()
	{
		int i1 , i2;
		float f1 , f2;
		cout << "Enter integer data " << endl;
		cin >> i1 >> i2;

		cout << "Enter float data " << endl;
		cin >> f1 >> f2;

		add( i1 , f1 );
		add( i1 , i2 );
		add( f1 , i1 );
		add( f1 , f2 );
	}