	
	#include<iostream.h>	
	
	float avg ( float , float );
	float avg ( float , float , float );

	void main( )
	{
		int t1 , t2 , t3 , ch;
		cout << "1. Select this option , if student attended only 2 tests " << endl
			 << "2. Select this option , if student attended only 3 tests " << endl;

		cin >> ch;
		if( ch == 1 )
		{
		 cout << "Enter marks secured in test-1,2" << endl;
		 cin >> t1 >> t2;
		 cout << "Average = " << avg( t1 , t2 ) << endl;
		}
		else
		{
		   cout << "Enter marks secured in test-1,2,3" << endl;
		   cin >> t1 >> t2 >> t3;
		   cout << "Average = " << avg( t1 , t2 , t3 ) << endl;
		}
	}

	float avg( float t1 , float t2 )
	{
		return ( t1 + t2 ) / 2.0;
	}

	float avg( float t1 , float t2 , float t3 )
	{
		if( t1 < t2 && t1 < t3 )
			return ( t2 + t3 ) / 2.0;

		else if( t2 < t1 && t2 < t3 )
			return ( t1 + t3 ) / 2.0;

		else
			return ( t1 + t2) / 2.0;
	}
