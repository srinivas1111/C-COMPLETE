	#include<iostream.h>	

	int sum( int , int = 0 );

	void main()
	{
	  cout<< sum( 5 ) << endl;
	  cout << sum(5,10) << endl;
	}

	int sum( int s , int e )
	{
		int res=0;
		int i = s > e ? s : e;
		int small = s < e ? s : e;
		while( i != small-1 )
		{
			res = res + i;
			i--;
		}
		return res;
	}
