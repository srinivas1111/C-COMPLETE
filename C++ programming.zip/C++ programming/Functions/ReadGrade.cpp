
	#include<iostream.h>
	
	template<class T>
	void ReadGrade( T &arg )
	{
      if( sizeof( arg ) == 1 )   
	  cout << "Enter grade ( a,b,c)" << endl;
	  else
	  cout << "Enter grade ( 1,2,3)" << endl;

	  cin >> arg;
	}

	void main()
	{
	  char gr;
	  ReadGrade( gr );
	  cout << "U passed in " << gr << endl;

	  int ig;
	  ReadGrade( ig );
	  cout << "U passed in " << ig << endl;
	}

