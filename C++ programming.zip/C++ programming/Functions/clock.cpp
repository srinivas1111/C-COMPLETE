
	#include<iostream.h>
	#include<conio.h>
	#include<dos.h>
	#include<iomanip.h>


	void incr ( int & , int & , int & );

	void main( )
	{
		int h , m , s;
		clrscr();
		cout << "Enter start time \n";
		cin >> h >> m >> s;
		clrscr();
		while( !kbhit() )   // loop until key hit
		{
			incr( h , m , s );
		    gotoxy( 60 , 1 );  // cursor position on screen
			cout << setw(2) << h << ":" << setw(2) << m << ":" << setw(2) <<  s << endl;
			sleep(1);  // 1 sec delay
		}
	}

	void incr( int &h , int &m , int &s )
	{
		s++;
		if( s== 60 )
		{
			s = 0;
			m++;
			if( m == 60 )
			{
				m = 0;
				h++;
				if( h == 24 ) h = 0;
			}
		}
	}

