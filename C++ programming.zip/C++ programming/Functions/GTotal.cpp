
	#include<iostream.h>
	
	template<class P,class Q>
	double findTotal( P qty , Q unit )
	{
	  double total;
	  total = qty * unit;
	  return total;
	}

	void main()
	{
		cout << "Total amount = " << findTotal( 12 , 54 ) << endl;
		cout << "Total amount = " << findTotal( 45.6 , 90 ) << endl;
		cout << "Total amount = " << findTotal( 90.45 , 45.12 ) << endl;
		cout << "Total amount = " << findTotal( 45 , 89.3 ) << endl;
	}