	#include<iostream.h>	

	int sum( int );
	int sum ( int , int );

	void main()
	{
	  cout<< sum( 5 ) << endl;
	  cout << sum(5,10) << endl;
	}

	int sum( int n )
	{
		int s=0;
		for( int i=1; i<=n; i++)
			s = s + i;
		
		return s;
	}

	int sum( int n , int range )
	{
		int s=0;
		for( int i=n; i<=range; i++)
			s = s + i;
		
		return s;
	}