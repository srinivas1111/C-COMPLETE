
	#include<iostream.h>
	#include<swap.h>
	#include<conio.h>
	void main( )
	{
	int i1 , i2;
	float f1 , f2;
	char c1 , c2;
	
	clrscr();	
	cout << "Enter integer values \n";
	cin >> i1 >> i2;
	swap( i1 , i2 );

	cout << "Enter float values \n";
	cin >> f1 >> f2;
	swap( f1 , f2 );

	cout << "Enter character values \n";
	cin >> c1 >> c2;
	swap( c1 , c2 );

	cout << "After swapping \n"
                           << i1 << "\t" <<i2 << endl
                           << f1 << "\t" << f2 << endl
                           << c1 << "\t" << c2 << endl;

	getch();
	}
	       