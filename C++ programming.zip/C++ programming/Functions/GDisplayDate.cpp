
	#include<iostream.h>

	template<class P,class Q>
	void displayDate( P day , Q mon ,int year );

	void main()
	{
	  displayDate( 9 , 5 , 2012 );
	  displayDate( 10 , "july", 2013 );
	  displayDate( "5th monday", 4 , 2011 );
	  displayDate( "7th friday", "june", 2012 );
	}

	template<class P,class Q>
	void displayDate( P day , Q mon ,int year )
	{
		cout << day << "-" << mon << "-" << year << endl;
	}