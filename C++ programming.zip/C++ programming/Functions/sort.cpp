
	#include<iostream.h>
	#include<conio.h>
	#include<sort.h>

	void main()
	{
	int a[]=  {1200,21015,17,12167,4};
	float f[]= {9.4 ,1.1 , 5.1 , 6.2,2.6};
	char name[][20] = {"harry","syed", "bhuvi", "eshwar", "bharath"};

	clrscr();

	sort(a,5);
	sort(f,5);
	sort(name,5);

	for(int i=0; i<=4; i++)
	cout << a[i] << "\t" << f[i] << "\t" << name[i] << endl;

	getch();
	}	


