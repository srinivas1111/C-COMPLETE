	#include<math.h>

	float area( float radius )
	{
	  return 3.14 * radius * radius;
	}

	float area( float b , float h )
	{
	  return b * h; 
	}

	float area( float a , float b , float c )
	{
	 float s = (a+b+c)/2.0;
	
	 return sqrt( s*(s-a)+(s-b)+(s-c) );
	}
	


