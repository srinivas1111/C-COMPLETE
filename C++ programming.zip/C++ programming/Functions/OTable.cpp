	
	#include<iostream.h>	
	
	void table( int , int = 10 );

	void main()
	{
		int num;
		cout << "Enter number \n";
		cin >> num;
		cout << "Table for given number" << endl;
		table ( num );
		cout << "Table upto range specified" << endl;
		table( num , 15 );
	}

	void table( int num , int range )
	{
		for( int i=1; i<=range; i++)
			cout << num << " x " << i << " = " << num * i << endl;
	}