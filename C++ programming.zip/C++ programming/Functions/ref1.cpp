
	#include<iostream.h>
	
	void move( int & , int & );
	void main( )
	{
	 int a = 10 ,b = 20;
	 move( a , b );
	 cout << a << endl << b << endl;
	}

	void move ( int &x , int &y)
	{
		x++;
		y++;
	}

	
