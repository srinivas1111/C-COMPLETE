
	#include<iostream.h>
	void print ( int , int );

	void main( )
	{
		int n;
		cout << "Enter number " << endl;
		cin >> n;
		for( int i=1; i<=10; i++)
			print ( n , i );
	}

	void print( int num , int ndx )
	{
		cout << num << " x " << ndx << " = " << num*ndx << endl;
	}