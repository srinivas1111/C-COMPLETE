
	#include<iostream.h>

	void main()
	{
	  int h , m , s;
	  cout << "Enter time" << endl;
	  cin >> h >> m >> s;
	  if( h < 12 )
		  cout << h << ":" << m << ":" << s << " am" << endl;
	  else if( h == 12 )
		  cout << h << ":" << m << ":" << s << " pm" << endl;
	  else
		  cout << h-12 << ":" << m << ":" << s << " pm" << endl;
	}