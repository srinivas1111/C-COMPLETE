

	#include<iostream.h>
	#include<string.h>
	#include<conio.h>

	void main()
	{
	   char user[20] , pwd[20];

	   clrscr();

	   cout << "Username " << endl;
	   cin >> user;


	   strcpy( pwd , getpass( "Password ") );


	   if( strcmp( user , "admin") == 0 && strcmp( pwd , "un777") == 0 )
	     cout << "\n\n\nValid user" << endl;
	   else
	     cout << "\n\n\nInvalid user" << endl;

	   getch();
	}





