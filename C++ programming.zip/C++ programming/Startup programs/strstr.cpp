
	#include<iostream.h>
	#include<string.h>

	void main()
	{
		char sent[ ] = {"Represents the local device Bluetooth adapter. The BluetoothAdapter lets you perform fundamental Bluetooth tasks, such as initiate device discovery, query a list of bonded (paired) devices"};
		char word[10];

		cout << "Enter word \n";
		cin >> word;
		
		if( strstr( sent , word ) == NULL )
			cout << "Not present....." << endl;
		else
			cout << "Present" << endl;
	}