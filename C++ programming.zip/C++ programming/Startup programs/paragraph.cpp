
	#include<iostream.h>
	#include<stdio.h>

	void main()
	{ 
	  char para[600];
	  int c=0;
	  
	  cout << "Enter paragraph" << endl;
	  cin . getline( para, 600 , '#');
	  
	  for(int i=0; para[i]!='\0'; i++)
		if( para[i] == '\n' || para[i] == '\r') c++;

		cout << "Number of lines = " << c + 1 << endl;
	}


	  