
	#include<iostream.h>
	#include<stdlib.h>

	void main()
	{ 
		char f[10] , s[10];
		int res;

		cout << "Enter 2 numbers" << endl;
		cin >> f >> s;

		res = atoi( f ) + atoi( s );

		cout << "Sum = " << res << endl;
	}

