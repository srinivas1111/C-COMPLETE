
	#include<iostream.h>
	#include<stdio.h>

	void main()
	{ 
		int regno;
		char name[20];

		cout << "Enter regno and name \n";
		cin >> regno;
		cin.ignore();

		cin.getline( name , 20 );

		cout << "Hi " << name << " ur regno is " << regno << endl;
	}


	  