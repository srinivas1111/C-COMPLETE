
	#include<iostream.h>
	#include<ctype.h>

	void main()
	{ 
		char word[20];
		cout << "Enter word \n";
		cin.getline( word, 20 );

		for( int i=0; word[i]!='\0'; i++)
		{
		  if( isalpha( word[i] ) )
		  {
			if( word[i] == 90 || word[i] == 122 )
			  word[i] = word[i] - 25;
		   else
			  word[i]++;
		  }
		}

		cout << "Encoded word \n" << word << endl;
	}

 
	