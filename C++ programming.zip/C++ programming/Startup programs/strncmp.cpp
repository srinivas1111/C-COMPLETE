
	#include<iostream.h>
	#include<string.h>

	void main()
	{
		char mobile[11];
		cout << "Enter mobile number " << endl;
		cin >> mobile;

		if( strncmp( mobile , "9845", 4 ) == 0 )
			cout << "Number belongs to airtel " << endl;

		else if( strncmp( mobile,"9342" , 4 ) ==0 )
			cout << "Number belongs to reliance" << endl;
		else
			cout << "Some other provider"<< endl;
	}
	 