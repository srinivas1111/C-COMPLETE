
	#include<iostream.h>
	#include<stdio.h>

	void main()
	{ 
		 int h = 10 , m = 34 , s = 56;
		 char time[20];
		 
		 sprintf( time , "%d:%d:%d", h , m , s );

		 cout << time << endl;
	}

 


