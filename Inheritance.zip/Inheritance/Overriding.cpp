	#include<iostream.h>

	class N70
	{
	public:
		void call( )
		{
		cout << "Call feature.." << endl;		
		}

		void sms()
		{
		cout << "Messaging feature.." << endl;		
		}	

		void camera( )
		{
		 cout << "Basic camera feature (b/w)" << endl;
		}
	};

	class N80 : public N70
	{
	public:
	
		void camera()
		{
		cout << "* Color camera" << endl
			 << "* Face detection" << endl
			 << "* Photo tag" << endl
			 << "* Smile detection" << endl;
		}

		void calendar()
		{
		cout << "Manage task , calendar , alarms " << endl;
		}	
	};


	void main()
	{
		N80 n;
			n.call();
			n.sms();
			n.calendar();
			n.camera();
	}

	
	
	
