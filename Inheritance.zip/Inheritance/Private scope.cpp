
	#include<iostream.h>

	class BC
	{
	public:
		int cube( int n )
		{
		return n * n * n;
		}
	};

	class DC : private BC
	{
	public:	
		int Formula( int a , int b )
		{	
		 int c=BC::cube(a) + BC::cube(b);
		 return c;
		}
	};


	void main()
	{
	   
	  int a ,b ;	
	  cout << "Enter value for a , b" << endl;
	  cin >> a >> b;

	  DC d;	
	  
	  //cout << d.cube(a) << endl;

	  cout << "Result = " << d.Formula( a , b );

	  
	}

	
	
