 
		#include<iostream.h>

		class Galaxy1
		{
		public:		
				void call()
				{
					cout << "Call feature" << endl;
				}
				void sms()
				{
					cout << "Message feature" << endl;
				}
		};

		class Galaxy2 : public Galaxy1
		{
		public:
					void voiceControl()
					{
					 cout << "Voice commmanding" << endl;
					}

					void radio()
					{
						cout << "Fm radio" << endl;
					}
		};

		void main()
		{
			Galaxy2 g;
			g.call();
			g.sms();
			g.radio();
			g.voiceControl();
		}