
	#include<iostream.h>

	class BC
	{
	public:
			int add ( int a , int b )
			{
				return a + b;
			}
	};

	class DC : public BC
	{
	public:
			int mul( int a , int b )
			{
			 int s = 0;
			 for( int i=1; i<=b; i++)
				 s = BC::add( a, s );

			 return s;
			}
	};
	
	void main()
	{
		int a , b;
		cout << "Enter value for a and b " << endl;
		cin >> a >> b;
		
		DC obj;
		cout << "Addition = " << obj.add( a, b ) << endl;
		cout << "Multiplication = " << obj.mul( a, b) << endl;
	}
