
	#include<iostream.h>

	void main()
	{
	  int *p , n , ac=0 , kc=0 , mc=0;

	  cout << "Enter persons count" << endl;
	  cin >> n;

	  p = new int [ n ];
	  cout << "Enter each person age" << endl;

	  for(int i=0; i<n; i++)
	  {
		cin >> *(p+i);
		if( *(p+i) >= 18 ) ac++;
		else if( *(p+i) > 12 ) mc++;
		else
		kc++;
	  }

	  cout << "Count of adults = " << ac << endl
		   << "Count of minors = " << mc << endl
		   << "Count of kids   = " << kc << endl;

	  delete p;
	}