	#include<iostream.h>

	class Bank
	{
	private:
			 int amount;
	public:
			 Bank()
			 {
				amount = 250;  // assume minimum balance
			 }
			 
			 void Deposit( int amt )
			 {
				amount = amount + amt;
			 }

			 void Withdraw( int amt )
			 {
				if( (amount - amt) < 250 )
				   cout << "Not enough balance" << endl;
				else
					amount = amount - amt;
			 }

			 void Balance()
			 {
				cout << "Balance = " << amount << endl;
			 }

			  void MoneyTransfer( Bank &arg , int val )
			  {
				amount = amount - val;
				arg.amount = arg.amount + val;
			  }

			  ~Bank()
			  {
				cout << "All your transactions are updated and saved successfully at server" << endl;
			  }

		};

	    void main( )
		{
			Bank *c;
			int accno , amt , choice , saccno , taccno , max;
			cout << "Enter customer count" << endl;
			cin >> max;
			c = new Bank [ max ];

			while( 1 )
			{
				cout << "1. Deposit" << endl
					 << "2. Withdraw" << endl
					 << "3. Balance" << endl
					 << "4. Money transfer" << endl
					 << "5. Exit" << endl;

				cin >> choice;
				switch( choice )
				{
				case 1:		
						cout << "Enter accno and amount \n";
						cin >> accno >> amt;
						(c+accno)->Deposit(amt);
						break;
				case 2:
						cout << "Enter accno and amount \n";
						cin >> accno >> amt;
						(c+accno)->Withdraw(amt);
						break;
				case 3:
						cout << "Enter accno \n";
						cin >> accno ;
						(c+accno)->Balance();
						break;
				case 4:
						cout << "Source account number  , target account number and amount" << endl;
						cin >> saccno >> taccno >> amt;
						(c+saccno)->MoneyTransfer( c[taccno] , amt );
						break;
				case 5:
						delete [ ] c;
						return;
				}
			}
		}