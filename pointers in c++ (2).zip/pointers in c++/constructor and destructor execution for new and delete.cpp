
	#include<iostream.h>
	
	class A
	{
	public:
			A( )
			{
			 cout << "Constructor" << endl;
			}

			~A()
			{
	          cout << "Destructor" << endl;
			}
	};

	void main()
	{
		A *p;
		int n;
		cout << "Enter how many objects required \n";
		cin >> n;
		p = new A[ n ];

		delete [ ] p;
	}
	 
