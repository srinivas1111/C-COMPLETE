
	#include<iostream.h>
	class Student
	{
	private:
			int marks;
	public:
			void readMarks()
			{
			 cout << "Enter marks secured" << endl;
			 cin >> marks;
			}

			int getMarks()
			{
			  return marks;
			}

			void operator ++()
			{
				marks = marks + 1;
			}

			void writeMarks()
			{
				cout << "Marks secured = " << marks << endl;
			}
	};
	
	void main()
	{
	  Student s;
	  s.readMarks();
	  if( s.getMarks() < 100 ) 
	  ++s;

	  s.writeMarks();
	}