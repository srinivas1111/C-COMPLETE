
	#include<iostream.h>
	class Employ
	{
	private:
			int exp , salary;
	public:
			void Read()
			{
			  cout << "Enter experience and salary \n";
			  cin >> exp >> salary;
			}

			void operator +=( int val )
			{
				salary = salary + val;
			}

			void Write()
			{
				cout << "---------------------" << endl;
				cout << "Experience  :" << exp << endl
					 << "Salary      :" << salary << endl
					 << "---------------------" << endl;
			}

			int operator == ( Employ &arg )
			{
				return exp == arg.exp ? 1 : 0;
			}

			int operator > ( Employ &arg )
			{
				return exp > arg.exp ? 1 : 0;
			}
	};


	void main()
	{
		Employ e1 , e2;
		e1.Read();
		e2.Read();

		if( e1 == e2 )
		{
				e1+=5000;
				e2 +=5000;
		}
		else if( e1 > e2 )
				e1+=5000;
		else
				e2+=5000;

		e1.Write();
		e2.Write();
	}