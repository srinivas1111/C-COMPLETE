
	#include<iostream.h>

	class Matrix
	{
	private:
		int V[10][10] , rows , cols;
	public:

		friend istream& operator >> ( istream &in , Matrix &arg )
		{

		 cout << "Enter matrix dimension" << endl;
		 in >> arg.rows >> arg.cols;

		 cout << "Enter matrix elements" << endl;

		 for(int i=0; i<arg.rows; i++)
		 for(int j=0; j<arg.cols; j++)

		 in >> arg.V[i][j];

		 return in;
		}

		friend ostream & operator << ( ostream &out , Matrix &arg )
		{

		 out << "Matrix " << endl;

		 for(int i=0; i<arg.rows; i++)
		 {
		     for(int j=0; j<arg.cols; j++)
			 out << arg.V[i][j] << "\t";


		  out << endl;
		 }

		 return out;
	       }


	       int operator == ( Matrix arg )
	       {
			 return rows == arg.rows && cols == arg.cols ? 1 : 0;
	       }


	       Matrix operator + ( Matrix arg )
	       {

			Matrix temp;

			temp.rows = rows;
			temp.cols = cols;
	
			for(int i=0; i<arg.rows; i++)
			for(int j=0; j<arg.cols; j++)
		    temp.V[i][j] = V[i][j] + arg.V[i][j];

			 return temp;
	       }

	       Matrix operator - ( Matrix arg )
	       {

			 Matrix temp;

			 temp.rows = rows;
	 	   	 temp.cols = cols;

			 for(int i=0; i<arg.rows; i++)
			 for(int j=0; j<arg.cols; j++)

		     temp.V[i][j] = V[i][j] - arg.V[i][j];
			 return temp;
	       }
	};

	void main()
	{
	 Matrix m1, m2 , m3 , m4;
	 cin >> m1 >> m2;
	 if( m1 == m2 )
	 {
	   m3 = m1 + m2;
	   m4 = m1 - m2;
	   cout << m1 << m2 << m3 << m4;
	 }
	 else
	 cout << "Matrix addition / substraction not possible" << endl;
      }






















