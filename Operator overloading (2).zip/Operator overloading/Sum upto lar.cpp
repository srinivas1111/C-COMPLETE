	#include<iostream.h>

	class Array
	{
	private:
		int v[100] , max;
	public:
	Array()
	{
		for( int i=0; i<100; i++)
			v[i]=0;
	}

	friend istream & operator >> ( istream &in , Array &arg)
	{
	  cout << "Enter array size" << endl;
	  in >> arg.max ;
	  for(int i=0; i<arg.max; i++)
		  in >> arg.v[i];

	 return in;
	}

	friend ostream & operator << ( ostream &out , Array &arg)
	{
	  cout << "\nArray" << endl;
	  for(int i=0; i<arg.max; i++)
		  out << arg.v[i] << "\t";

	 return out;
	}

	Array operator + ( Array &arg )
	{
		Array temp;
		temp.max = max > arg.max ? max : arg.max;

		for(int i=0; i<temp.max; i++)
			temp.v[i] = v[i] + arg.v[i];

		return temp;
	}

	};


	void main()
	{
		Array a , b , c;
		cin >> a >> b;
		c = a + b;
		cout << a << b << c;
	}

	