
	#include<fstream.h>
	#include<stdio.h>
	
	void main( )
	{	
		int num;
		char filename[20];
		cout << "Enter number " << endl;
		cin >> num;

		sprintf( filename , "d:/%d.txt", num );

		ofstream fp( filename );

		for( int i=1; i<=10; i++)
		  fp << num << " x " << i << " = " << num * i << endl;

		fp.close();
	}