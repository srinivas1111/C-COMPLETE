	#include<fstream.h>
	#include<conio.h>
	#include<dos.h>
	
	void main( )
	{		
	 char filename[20] , ch;
	 clrscr();

	 cout << "Enter filename" << endl;
	 cin >> filename;

	 ifstream fp ( filename );
	 if( fp.fail( ) )
	 cout << "Sorry file not found/Invalid path" << endl;
	 else
	 {
		do
		{	
		 ch = fp.get( );
		 cout << ch;
		 delay(20);
		}
		while( ! fp.eof() );
		fp.close();
		getch();
	}

	}
			 
		 

	
	
	