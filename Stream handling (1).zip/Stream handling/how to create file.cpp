
	#include<fstream.h>
	
	void main( )
	{	
		ofstream fp("d:/news.txt");
		fp << "All is well !!! , no news ";
		fp.close( );
	}