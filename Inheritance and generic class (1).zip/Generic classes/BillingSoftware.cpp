
	#include<iostream.h>
	
	template<class P,class Q>
	class BillingSoftware
	{
	private:	
			P unit;
			Q qty;
	public:
			void setDetails( )
			{
			  cout << "Enter unit price and qty" << endl;
			  cin >> unit >> qty;
			}

			double findTotal()
			{
			   return unit * qty;
			}
	};

	void main()
	{
	  BillingSoftware<float,int>p;
	  p.setDetails();
	  cout << "Total amount = " << p.findTotal() << endl;
	}