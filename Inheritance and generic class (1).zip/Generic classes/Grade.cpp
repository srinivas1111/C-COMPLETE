
	#include<iostream.h>
	 
	template<class T>
	class Student
	{
	private:
			int regno;
			char name[20];
			T grade;
	public:
			void read()
			{
				cout << "Enter regno and name " << endl;
				cin >> regno >> name;
				cout << "Enter grade" << endl;
				cin >> grade;
			}

			void write()
			{
			  cout << "-------------------------" << endl
				   << "Register number : " << regno << endl
				   << "Name            : " << name << endl
				   << "Grade           : " << grade << endl
				   << "-------------------------" << endl;
			}

	};

	void main()
	{
		Student<int> s1;
		Student<char> s2;

		s1.read();
		s2.read();
		
		s1.write();
		s2.write();
	}