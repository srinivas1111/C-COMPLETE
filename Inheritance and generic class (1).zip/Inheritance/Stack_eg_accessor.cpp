
	#include<iostream.h>
	
	class BasicStack
	{
	private:
			int V [ 100 ];
	 
			int top, max;
	public:
			int getTop()
			{
			 return top;
			}

			int getMax()
			{	
			  return max;
			}

			BasicStack()
			{
			 max = 5;
			 top = -1;
			 cout << "Stack created for size 5" << endl;
			}
			BasicStack(int size)
			{
				max = size;
				top = -1;
			}

			void push( int e )
			{
				cout << e << " pushed into stack\n";
				V[++top] = e;
			}

			void pop()
			{
			  cout << "Poped element = " << V[top--] << endl;
			}
 
	};

	class Stack : public BasicStack 
	{
	public:
			Stack()
			{
				cout << "Stack is ready to use" << endl;
			}

			Stack( int sz ):BasicStack( sz )
			{
			  cout << "Stack created as per the size i.e " << sz << endl;
			}

			void push( int e )
			{
				if( getTop() == getMax()-1 )
					cout << "Stack overflow " << endl;
				else
					BasicStack::push( e );
			}

			void pop()
			{
				if( getTop() == -1 )
					cout << "Stack empty" << endl;
				else
					BasicStack::pop();
			}
	};

	void main()
	{
		Stack s( 3 );
		s.push( 10 );
		s.push( 20 );
		s.push( 30 );
		s.push( 40 );
		s.push( 56 );
		s.push( 60 );

		s.pop();
		s.pop();
		s.pop();
		s.pop();
		s.pop();
		s.pop();
	}


