
	#include<iostream.h>
	
	class iMarks
	{
	private:	
			 int marks;
	public:
			void readInternalMarks()
			{
				cout << "Enter internal marks" << endl;
				cin >> marks;
			}

			int getInternalMarks()
			{
				return marks;
			}
	};

	class eMarks
	{
	private:	
			 int marks;
	public:
			void readExternalMarks()
			{
				cout << "Enter external marks" << endl;
				cin >> marks;
			}

			int getExternalMarks()
			{
				return marks;
			}
	};

	class Board : public iMarks , public eMarks
	{
	private:	
			int total;
	public:
			int getTotal()
			{
				return total;
			}

			void EvalResult()
			{
				total = getInternalMarks() + getExternalMarks();
			}

			void Display()
			{
				cout << "-----------------------" << endl;
				cout << "internal marks = " << getInternalMarks() << endl;
				cout << "External marks = " << getExternalMarks() << endl;
				cout << "Total          = " << total << endl;
				if( total >= 50 )
				cout << "Result         = Pass" << endl;
				else
				cout << "Result         = Fail" << endl;
				cout << "------------------------" << endl;
			}
	};

	void main()
	{
		Board s[100];
		int max;
		cout << "How many students records to store limit( 1 - 100)" << endl;
		cin >> max;
		
		for( int i=0; i<max; i++)
		{
			s[i].readInternalMarks();
			s[i].readExternalMarks();
			s[i].EvalResult();
		}

		cout << "All passed students" << endl;
		for( i=0; i<max; i++)
		{
			if( s[i].getTotal() >= 50 )
				s[i].Display();
		}

		cout << "All failed students" << endl;
		for( i=0; i<max; i++)
		{
			if( s[i].getTotal() < 50 )
				s[i].Display();
		}
	}