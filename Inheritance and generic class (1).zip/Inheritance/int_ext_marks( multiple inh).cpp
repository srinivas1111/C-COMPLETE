
	#include<iostream.h>
	
	class iMarks
	{
	private:	
			 int marks;
	public:
			void readInternalMarks()
			{
				cout << "Enter internal marks" << endl;
				cin >> marks;
			}

			int getInternalMarks()
			{
				return marks;
			}
	};

	class eMarks
	{
	private:	
			 int marks;
	public:
			void readExternalMarks()
			{
				cout << "Enter external marks" << endl;
				cin >> marks;
			}

			int getExternalMarks()
			{
				return marks;
			}
	};

	class Board : public iMarks , public eMarks
	{
	public:
			void EvalResult()
			{
				int total = getInternalMarks() + getExternalMarks();
				cout << "-----------------------" << endl;
				cout << "internal marks = " << getInternalMarks() << endl;
				cout << "External marks = " << getExternalMarks() << endl;
				cout << "Total          = " << total << endl;
				if( total >= 50 )
				cout << "Result         = Pass" << endl;
				else
				cout << "Result         = Fail" << endl;
				cout << "------------------------" << endl;
			}
	};

	void main()
	{
		Board s1;
		s1.readInternalMarks();
		s1.readExternalMarks();
		s1.EvalResult();
	}