
	#include<iostream.h>
	
	class Circle
	{
	private:
			float r , a;
	public:
			void setRadius( float rad )
			{
				r = rad;
				a = 3.14 * r * r;
			}

			operator float()
			{
				return a;
			}
	};

	void main()
	{
		Circle c;
		c.setRadius( 8.2 );

		float res = c;
		cout << "Area = " << res << endl;
	}
