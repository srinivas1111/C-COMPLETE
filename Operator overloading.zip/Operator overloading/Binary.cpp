
	#include<iostream.h>
	#include<string.h>

	class Binary
	{
	private:
			int num;
			char s[20];
	public:
			Binary()
			{
			  strcpy( s , "");
			}	

			void operator = ( int val )
			{
			   num = val;
			   while( num != 0 )
			   {
				int rem = num % 2;
				if( rem == 0 )
					strcat( s , "0");
				else
					strcat( s , "1");

				num = num / 2;
			   }
			   strrev( s );
			}

			friend ostream & operator << ( ostream &out , Binary &arg)
			{
				out << arg.s << endl;
				return out;
			}
	};


	void main()
	{
		int n;
		cout << "Enter number " << endl;
		cin >> n;
		Binary b;
		b = n;
		cout << b;
	}