
	#include<iostream.h>

	class GPS
	{
	private:
			int x , y;
	public:
			void set( int xval , int yval )
			{
				x = xval;
				y = yval;
			}

			void get( )
			{
				cout << x << "," << y << endl;
			}
	
			void operator ++()
			{
				++x;
				++y;
			}
	};	

	void main()
	{
	  GPS g;
	  g.set( 10 , 20 );
	  ++g;
	  g.get();
	}

	