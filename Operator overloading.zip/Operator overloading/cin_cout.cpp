
	#include<iostream.h>
	class Employ
	{
	private:
			int exp , salary;
	public:
		 
	friend istream& operator >> ( istream &in,Employ &arg)
	{
			  cout << "Enter experience and salary \n";
			  in >> arg.exp >> arg.salary;
			  return in;
	}
		 
	void operator +=( int val )
	{
		salary = salary + val;
	}

	friend ostream& operator << (ostream &out, Employ &arg)
	{
		out << "---------------------" << endl;
		out << "Experience  :" << arg.exp << endl
			 << "Salary      :" << arg.salary << endl
			 << "---------------------" << endl;
		return out;
	}
			 
	int operator == ( Employ &arg )
	{
		return exp == arg.exp ? 1 : 0;
	}

	int operator > ( Employ &arg )
	{
		return exp > arg.exp ? 1 : 0;
	}

	int operator < ( Employ &arg )
	{
		return exp < arg.exp ? 1 : 0;
	}
	};


	void main()
	{
		Employ e1 , e2;
		cin >> e1 >> e2;
		if( e1 == e2 )
		{
				e1+=5000;
				e2 +=5000;
		}
		else if( e1 > e2 )
				e1+=5000;
		else
				e2+=5000;
		cout << e1 << e2;
	}