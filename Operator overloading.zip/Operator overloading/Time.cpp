	#include<iostream.h>
	
	class Time
	{
	private:	
			int h , m , s;
			void Increment( int val)
			{
				int res = h * 3600 + m * 60 + s;
	
				res = res + val;
				s = res % 60;
		
				res = res / 60;
				m = res % 60;
	
				res = res / 60;
				h = res % 60;
				h = h % 24;
			}
	public:	
			void setTime( int H , int M , int S )
			{
			  h = H;
			  m = M;
			  s = S;
			}

			void operator ++()
			{
				Increment( 1 );
			}

			void operator +=( int val )
			{
				 Increment( val );
			}

		friend ostream & operator << ( ostream &out , Time &arg)
		{
			out << arg.h << ":" << arg.m << ":" << arg.s << endl;
			return out;
		}
	};

	void main()
	{
		Time t;
		t.setTime( 23 , 59 , 59 );
		++t;
		cout << t;
		t+=300;
		cout << t;
	}




