
	#include<iostream.h>
	#include<string.h>

	class String
	{
	private:
			char val[40];
	public:
		String(){  }

		void operator =(char arg[] )
		{
			strcpy( val , arg );
		}

		String ( char arg[] )
		{
			strcpy( val , arg );
		}

		String operator + ( String &obj )
		{
			 String temp;
			 strcpy( temp.val , val );
			 strcat( temp.val , obj.val );
			 return temp;
		}

		friend ostream& operator << ( ostream &out , String &arg)
		{
			out << arg.val << endl;
			return out;
		}
	};


	void main()
	{
	  String fname;
	  fname = "Mr.Smith ";
	  String sname = " jones";

	  String name = fname + sname;
	  cout << fname << sname << name << endl;
	}